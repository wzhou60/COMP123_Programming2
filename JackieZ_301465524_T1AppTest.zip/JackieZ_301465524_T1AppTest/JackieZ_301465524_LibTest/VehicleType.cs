﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JackieZ_301465524_LibTest
{
    public enum VehicleType
    {
        Car, 
        Bus
    }
}
