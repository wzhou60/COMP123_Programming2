﻿ 
public enum EvaluationType
{
    Assignment,
    Test,
    Quiz,
    Discussion,
    Project
}