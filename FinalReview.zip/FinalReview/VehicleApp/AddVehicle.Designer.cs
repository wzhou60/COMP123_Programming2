﻿namespace VehicleApp
{
    partial class AddVehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            rbtnMotorcycle = new RadioButton();
            rbtnCar = new RadioButton();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtMake = new TextBox();
            txtModel = new TextBox();
            numericYear = new NumericUpDown();
            numericDoorCount = new NumericUpDown();
            chkSidecar = new CheckBox();
            btnOk = new Button();
            btnCancel = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericYear).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericDoorCount).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rbtnMotorcycle);
            groupBox1.Controls.Add(rbtnCar);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(223, 73);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Vehicle Type";
            // 
            // rbtnMotorcycle
            // 
            rbtnMotorcycle.AutoSize = true;
            rbtnMotorcycle.Location = new Point(12, 47);
            rbtnMotorcycle.Name = "rbtnMotorcycle";
            rbtnMotorcycle.Size = new Size(88, 19);
            rbtnMotorcycle.TabIndex = 1;
            rbtnMotorcycle.TabStop = true;
            rbtnMotorcycle.Text = "Motor cycle";
            rbtnMotorcycle.UseVisualStyleBackColor = true;
            // 
            // rbtnCar
            // 
            rbtnCar.AutoSize = true;
            rbtnCar.Location = new Point(14, 22);
            rbtnCar.Name = "rbtnCar";
            rbtnCar.Size = new Size(43, 19);
            rbtnCar.TabIndex = 0;
            rbtnCar.TabStop = true;
            rbtnCar.Text = "Car";
            rbtnCar.UseVisualStyleBackColor = true;
            rbtnCar.CheckedChanged += rbtnCar_CheckedChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 94);
            label1.Name = "label1";
            label1.Size = new Size(36, 15);
            label1.TabIndex = 1;
            label1.Text = "Make";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 123);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 2;
            label2.Text = "Model";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 151);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 3;
            label3.Text = "Year";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 180);
            label4.Name = "label4";
            label4.Size = new Size(67, 15);
            label4.TabIndex = 4;
            label4.Text = "Door count";
            // 
            // txtMake
            // 
            txtMake.Location = new Point(110, 91);
            txtMake.Name = "txtMake";
            txtMake.Size = new Size(125, 23);
            txtMake.TabIndex = 5;
            // 
            // txtModel
            // 
            txtModel.Location = new Point(108, 120);
            txtModel.Name = "txtModel";
            txtModel.Size = new Size(127, 23);
            txtModel.TabIndex = 6;
            // 
            // numericYear
            // 
            numericYear.Location = new Point(108, 149);
            numericYear.Name = "numericYear";
            numericYear.Size = new Size(127, 23);
            numericYear.TabIndex = 7;
            // 
            // numericDoorCount
            // 
            numericDoorCount.Location = new Point(108, 178);
            numericDoorCount.Name = "numericDoorCount";
            numericDoorCount.Size = new Size(127, 23);
            numericDoorCount.TabIndex = 8;
            // 
            // chkSidecar
            // 
            chkSidecar.AutoSize = true;
            chkSidecar.Location = new Point(110, 207);
            chkSidecar.Name = "chkSidecar";
            chkSidecar.Size = new Size(105, 19);
            chkSidecar.TabIndex = 9;
            chkSidecar.Text = "Side car option";
            chkSidecar.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            btnOk.Location = new Point(12, 245);
            btnOk.Name = "btnOk";
            btnOk.Size = new Size(75, 23);
            btnOk.TabIndex = 10;
            btnOk.Text = "Ok";
            btnOk.UseVisualStyleBackColor = true;
            btnOk.Click += btnOk_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(153, 245);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 11;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // AddVehicle
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(247, 283);
            Controls.Add(btnCancel);
            Controls.Add(btnOk);
            Controls.Add(chkSidecar);
            Controls.Add(numericDoorCount);
            Controls.Add(numericYear);
            Controls.Add(txtModel);
            Controls.Add(txtMake);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Name = "AddVehicle";
            Text = "AddVehicle";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericYear).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericDoorCount).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton rbtnMotorcycle;
        private RadioButton rbtnCar;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtMake;
        private TextBox txtModel;
        private NumericUpDown numericYear;
        private NumericUpDown numericDoorCount;
        private CheckBox chkSidecar;
        private Button btnOk;
        private Button btnCancel;
    }
}