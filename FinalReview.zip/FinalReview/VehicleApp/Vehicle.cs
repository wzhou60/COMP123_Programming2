﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleApp
{
    abstract class Vehicle
    {
        public string Make { get; private set; }
        public string Model { get; private set; }
        public int Year { get; private set; }
        public virtual string FullDescription
            => $"{Make} {Model} {Year}";
        public abstract double Value { get; }
        public Vehicle(string make, string model, int year)
            => (Make, Model, Year) = (make, model, year);
        public abstract string StartEngine();
    }
    class Car : Vehicle
    {
        public int DoorCount { get; private set; }
        public override double Value 
            => 20_000 - 1_000 * (DateTime.Now.Year + 1 - Year) + 10_000 * (6 - DoorCount);
        public override string FullDescription 
            => $"{base.FullDescription} ({DoorCount}-doors) {Value:C}";
        public Car(string make, string model, int year, int doorCount)
            : base(make, model, year)
            => DoorCount = doorCount;

        public override string StartEngine()
            => "Car engine started: Vroom!";
    }
    class MotorCycle : Vehicle
    {
        public bool HasSideCar { get; private set; }
        public override double Value
            => 15_000 - 1_000 * (DateTime.Now.Year + 1 - Year) + 1_000 * (HasSideCar ? 1 : 0);
        public override string FullDescription
            => $"{base.FullDescription} {(HasSideCar ? "(with side car)" : "(with no side car)")} {Value:C}";
        public MotorCycle(string make, string model, int year, bool sideCar)
            : base(make, model, year)
            => HasSideCar = sideCar;

        public override string StartEngine()
            => "Morotcycle engine started: Vroom Vroom!";
    }
}
