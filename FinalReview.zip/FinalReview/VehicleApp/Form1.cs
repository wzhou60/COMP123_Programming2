namespace VehicleApp
{
    public partial class Form1 : Form
    {
        Dictionary<string, Vehicle> vehicles
            = new Dictionary<string, Vehicle>();
        public Form1()
        {
            InitializeComponent();
            InitGui();
            UpdateVehicleList();
        }
        void InitGui()
        {
            string key = "CAR001";
            Vehicle vehicle = new Car(
                "Toyota", "Camry", 2020, 4);
            vehicles[key] = vehicle;
            key = "MC002";
            vehicle = new MotorCycle(
                "Harley-Davision", "Sportster", 2021, false);
            vehicles.Add(key, vehicle);
            vehicles.Add(
                "CAR003",
                new Car("Ford", "Mustang", 2019, 2));
        }
        void UpdateVehicleList()
        {
            lstVehicle.Items.Clear();
            foreach (KeyValuePair<string, Vehicle> pair in vehicles)
            {
                lstVehicle.Items.Add($"{pair.Key}: {pair.Value.FullDescription}");
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (lstVehicle.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a Vehicle");
                return;
            }
            string key = lstVehicle.SelectedItem.ToString().Split(":")[0];
            Vehicle vehicle = vehicles[key];
            MessageBox.Show(vehicle.StartEngine(), "Engine Status");
        }

        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            AddVehicle form = new AddVehicle();
            if (form.ShowDialog() == DialogResult.OK)
            {
                Vehicle vehicle;
                string key;
                if (form.IsCar)
                {
                    //create car
                    vehicle = new Car(
                        form.Make,
                        form.Model,
                        form.Year,
                        form.DoorCount
                        );
                    key = $"CAR{vehicles.Count}";
                }
                else
                {
                    //motorcycle
                    vehicle = new MotorCycle(
                        form.Make,
                        form.Model,
                        form.Year,
                        form.HasSideCar);
                    key = $"CAR{vehicles.Count}";
                }
                //add vehicle to dictionary
                vehicles[key] = vehicle; 
                //update the list
                UpdateVehicleList();
            }
        }
    }
}
