﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VehicleApp
{
    public partial class AddVehicle : Form
    {
        public string Make { get; private set; }
        public string Model { get; private set; }
        public int Year { get; private set; }
        public int DoorCount { get; private set; }
        public bool HasSideCar { get; private set; }
        public bool IsCar { get; private set; }
        public AddVehicle()
        {
            InitializeComponent();
            InitGUI();
        }
        void InitGUI()
        {
            txtMake.Text = "Honda";
            txtModel.Text = "Civic";
            rbtnCar.Checked = true;
            chkSidecar.Checked = false;

            numericYear.Maximum = DateTime.Now.Year + 1;
            numericYear.Minimum = 1960;
            numericYear.Value = DateTime.Now.Year;

            numericDoorCount.Maximum = 8;
            numericDoorCount.Minimum = 2;
            numericDoorCount.Value = 4;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            //check for empty textboxes

            //set the properties on this form
            Make = txtMake.Text;
            Model = txtModel.Text;
            Year = (int)numericYear.Value;
            DoorCount = (int)numericDoorCount.Value;
            IsCar = rbtnCar.Checked;
            HasSideCar = rbtnCar.Checked;
            this.DialogResult = DialogResult.OK;
        }

        private void rbtnCar_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radio = sender as RadioButton;
            IsCar = radio.Text == "Car";

        }
    }
}
