﻿namespace VehicleApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStart = new Button();
            btnAddVehicle = new Button();
            lstVehicle = new ListBox();
            SuspendLayout();
            // 
            // btnStart
            // 
            btnStart.Location = new Point(12, 24);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(100, 47);
            btnStart.TabIndex = 0;
            btnStart.Text = "Start Engine";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // btnAddVehicle
            // 
            btnAddVehicle.Location = new Point(12, 88);
            btnAddVehicle.Name = "btnAddVehicle";
            btnAddVehicle.Size = new Size(100, 47);
            btnAddVehicle.TabIndex = 1;
            btnAddVehicle.Text = "Add Vehicle";
            btnAddVehicle.UseVisualStyleBackColor = true;
            btnAddVehicle.Click += btnAddVehicle_Click;
            // 
            // lstVehicle
            // 
            lstVehicle.FormattingEnabled = true;
            lstVehicle.ItemHeight = 15;
            lstVehicle.Location = new Point(133, 24);
            lstVehicle.Name = "lstVehicle";
            lstVehicle.Size = new Size(478, 109);
            lstVehicle.TabIndex = 2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(624, 146);
            Controls.Add(lstVehicle);
            Controls.Add(btnAddVehicle);
            Controls.Add(btnStart);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnStart;
        private Button btnAddVehicle;
        private ListBox lstVehicle;
    }
}
