﻿//Jackie Zhou 301465524 Lab2/3
public enum EvaluationType
{
    Assignment,
    Test,
    Quiz,
    Discussion,
    Project
}