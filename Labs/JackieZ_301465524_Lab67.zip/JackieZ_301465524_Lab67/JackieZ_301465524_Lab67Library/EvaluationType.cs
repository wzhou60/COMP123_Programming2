﻿//Jackie Zhou 301465524 Lab6/7
public enum EvaluationType
{
    Assignment,
    Test,
    Quiz,
    Discussion,
    Project
}