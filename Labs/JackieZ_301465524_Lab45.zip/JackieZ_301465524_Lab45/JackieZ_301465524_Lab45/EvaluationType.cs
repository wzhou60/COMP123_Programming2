﻿//Jackie Zhou 301465524 Lab4/5
public enum EvaluationType
{
    Assignment,
    Test,
    Quiz,
    Discussion,
    Project
}